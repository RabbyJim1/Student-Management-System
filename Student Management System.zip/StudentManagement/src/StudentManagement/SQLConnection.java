//package StudentManagement;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//
//import javax.swing.JOptionPane;
////import sun.jdbc.odbc.JdbcOdbcDriver;
//
//
//public class SQLConnection {
//	
//	 static Connection conn;
//	 
//	 public static void OpenConnection(){
//	 try {
//		 Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
//		 //DriverManager.registerDriver(new sun.jdbc.odbc.JdbcOdbcDriver());
//		 conn=DriverManager.getConnection("jdbc:mysql:DB//StudentManagement.sql");
//		 JOptionPane.showMessageDialog(null, "Connected");
//	 }
//	 catch (Exception e){
//		 JOptionPane.showMessageDialog(null,"Wrong Entry, Try Again");
//	 }
//
//}
//	 public static void main (String args[]){
//		 OpenConnection();
//	 }
//	 public static Connection GetConnection(){
//		 return conn;
//	}
//	 
//}
