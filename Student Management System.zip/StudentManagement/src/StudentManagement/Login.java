package StudentManagement;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.sql.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.SwingConstants;

public class Login extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFieldUsername;
	private JPasswordField passwordField;
	JButton button;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	/**
	 * Create the frame.
	 */
	
	Connection conn=null;
	private JButton btnBack;
	private JTextField textFieldUN;
	private JPasswordField passwordField_1;
	private JLabel label;
	private JLabel label_1;
	
	
	public Login() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/Image/Logo.jpg")));
		
		{
			initialize();
			conn = SqliteConnection.dbConnector();
			//conn = SQLConnection.GetConnection();
			
		}
		
		setTitle("Login - ARP");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textFieldUsername = new JTextField();
		textFieldUsername.setForeground(Color.BLACK);
		textFieldUsername.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textFieldUsername.setColumns(10);
		textFieldUsername.setBounds(481, 101, 164, 31);
		contentPane.add(textFieldUsername);
		
		passwordField = new JPasswordField();
		passwordField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent arg0) {
				if (arg0.getKeyCode()==KeyEvent.VK_ENTER){
			        
					button.doClick();
				}
			}
		});
		passwordField.setToolTipText("");
		passwordField.setFont(new Font("Tahoma", Font.PLAIN, 18));
		passwordField.setBounds(481, 165, 164, 31);
		contentPane.add(passwordField);
		
		button = new JButton("Login");
		button.setFont(new Font("Siyam Rupali", Font.PLAIN, 18));
		button.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent arg0) {
				try{
					String query="select * from Admin where Username=? and Password=?";
					
					PreparedStatement pst=conn.prepareStatement(query);
					pst.setString(1,textFieldUsername.getText());
					pst.setString(2,passwordField.getText());
					
					ResultSet rs = pst.executeQuery();
					int count = 0;
					while(rs.next()){
						count=count+1;
					}
					if(count == 1)
					{
						//JOptionPane.showMessageDialog(null,"Logged in successfully");
						
						
						AdminPanel frame = new AdminPanel();
						frame.setVisible(true);
						dispose();
						
						
					}
					else if (count > 1)
					{
						JOptionPane.showMessageDialog(null,"Duplicate username and Password");
					}
					else
					{
						JOptionPane.showMessageDialog(null,"Username and Password is not Correct");
					}
					
					rs.close();
					pst.close();
					
					
					
				}catch(Exception e1)
				{
					JOptionPane.showMessageDialog(null,e1);
					
				}
				
				

			}
		});
		button.setBounds(531, 234, 114, 39);
		contentPane.add(button);
		
		btnBack = new JButton("");
		btnBack.setIcon(new ImageIcon(Login.class.getResource("/Image/back.png")));
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Main window = new Main();
				window.frmStudentMangement.setVisible(true);
				dispose();
				
			}
		});
		btnBack.setBounds(559, 362, 66, 34);
		contentPane.add(btnBack);
		
		JButton buttonSignup = new JButton("SignUp");
		buttonSignup.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent arg0) {
				
				try{
					String query = "insert into Admin (Username,Password) values (?,?)";
					PreparedStatement pst = conn.prepareStatement(query);
					pst.setString(1, textFieldUN.getText());
					pst.setString(2, passwordField_1.getText());
					pst.execute();
					pst.close();
					JOptionPane.showMessageDialog(null, "Signup Successfully");
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				
			}
		});
		buttonSignup.setFont(new Font("Siyam Rupali", Font.PLAIN, 18));
		buttonSignup.setBounds(131, 234, 114, 39);
		contentPane.add(buttonSignup);
		
		textFieldUN = new JTextField();
		textFieldUN.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textFieldUN.setColumns(10);
		textFieldUN.setBounds(81, 101, 164, 31);
		contentPane.add(textFieldUN);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setToolTipText("");
		passwordField_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		passwordField_1.setBounds(81, 166, 164, 31);
		contentPane.add(passwordField_1);
		
		JLabel lblNewLabel_1 = new JLabel("Sign Up");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel_1.setBounds(63, 32, 182, 39);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Login");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel_2.setBounds(504, 32, 121, 39);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(Login.class.getResource("/Image/p1.png")));
		lblNewLabel_3.setBounds(318, 32, 46, 301);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon(Login.class.getResource("/Image/user.png")));
		lblNewLabel_4.setBounds(12, 82, 59, 58);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setIcon(new ImageIcon(Login.class.getResource("/Image/user.png")));
		lblNewLabel_5.setBounds(412, 79, 59, 61);
		contentPane.add(lblNewLabel_5);
		
		label = new JLabel("");
		label.setIcon(new ImageIcon(Login.class.getResource("/Image/pass.png")));
		label.setBounds(12, 151, 59, 58);
		contentPane.add(label);
		
		label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(Login.class.getResource("/Image/pass.png")));
		label_1.setBounds(412, 151, 59, 58);
		contentPane.add(label_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Login.class.getResource("/Image/background.jpg")));
		lblNewLabel.setBounds(0, 0, 694, 421);
		contentPane.add(lblNewLabel);
	}


	private void initialize() {
		// TODO Auto-generated method stub
		
	}
}
